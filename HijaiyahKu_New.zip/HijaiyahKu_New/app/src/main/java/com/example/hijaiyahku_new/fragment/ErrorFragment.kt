package com.example.hijaiyahku_new.fragment

import androidx.fragment.app.Fragment
import com.example.hijaiyahku_new.R

class ErrorFragment : Fragment(R.layout.custom_dialog_3) {
}