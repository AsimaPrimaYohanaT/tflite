package com.example.hijaiyahku_new.utils

enum class SoalSortType {

    TYPE_1,

    TYPE_2,

}