package com.example.hijaiyahku_new.fragment

import androidx.fragment.app.Fragment
import com.example.hijaiyahku_new.R

class SuccessFragment : Fragment(R.layout.custom_dialog_2) {
}